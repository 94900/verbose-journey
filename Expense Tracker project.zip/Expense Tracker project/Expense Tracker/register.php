<?php
	require_once 'core/init.php';
	Redirect::ifUserLoggedIn($user);
	if(Input::postExists() === true){
		$form = new Form('registerUser');
		$form->validate();
		if($form->errorStatus() === false){
			$userRegistration = $user->register($form->getInputs());
			if($userRegistration !== false){
				// registered successfully
				if(is_null($userRegistration) === false AND is_object($userRegistration) === true){
					$userRegistration = (object)$userRegistration;
					if(count(get_object_vars($userRegistration)) > 0 AND isset($userRegistration->status) === true AND isset($userRegistration->type) === true AND isset($userRegistration->message) === true){
						// response is ok
						if($userRegistration->status === true){
							switch($userRegistration->type){
								case 1:
									// registered and logged in
									Redirect::to('index', (object)[
										'registration'		=> 'success',
									]);
								break;
								case 2:
									// registered, but not logged in
									Redirect::to('login', (object)[
										'registration'		=> 'success',
									]);
								break;
								default:
									// some unknown error
									$error = $user->getError();
								break;
							}
						} else {
							// some unknown error occurred
							$errorMessages = $user->getError();
						}
					} else {
						// some unknown error occurred
						$errorMessages = $user->getError();
					}
				} else {
					// some unknown error occurred
					$errorMessages = $user->getError();
				}
			} else {
				// registration failed
				$errorMessages = $user->getError();
			}
		} else {
			// form validation errors
			foreach($form->getErrors() as $err){
				array_push($errorMessages, $err);
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Register | <?php echo Config::get('appData/name/full'); ?></title>

		<!-- Custom fonts for this template-->
		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link
				href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
				rel="stylesheet">

		<!-- Custom styles for this template-->
		<link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

		<div class="container">

				<div class="card o-hidden border-0 shadow-lg my-5">
						<div class="card-body p-0">
								<!-- Nested Row within Card Body -->
								<div class="row">
										<div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
										<div class="col-lg-7">
												<div class="p-5">
													<?php require_once 'partials/alert.php'; ?>
														<div class="text-center">
															<h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
														</div>
														<form class="user" action="register.php" method="POST">
																<div class="form-group row">
																		<div class="col-sm-6 mb-3 mb-sm-0">
																			<input type="text" name="firstName" class="form-control form-control-user" id="exampleFirstName" placeholder="First Name" required autocomplete="off" autofocus>
																		</div>
																		<div class="col-sm-6">
																			<input type="text" name="lastName" class="form-control form-control-user" id="exampleLastName" placeholder="Last Name" required autocomplete="off">
																		</div>
																</div>
																<div class="form-group row">
																	<div class="col-sm-12 mb-3 mb-sm-0">
																		<input type="email" name="uesrEmail" class="form-control form-control-user" id="exampleInputEmail" placeholder="Email Address" required autocomplete="off">
																	</div>
																</div>
																<div class="form-group row">
																	<div class="col-sm-6 mb-3 mb-sm-0">
																		<input type="tel" name="userPhone" class="form-control form-control-user" placeholder="Phone No" required autocomplete="off">
																	</div>
																	<div class="col-sm-6 mb-3 mb-sm-0">
																		<input type="password" name="userPassword" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" required autocomplete="off">
																	</div>
																</div>
																<div class="form-group row">
																	<div class="col-sm-4 mb-3 mb-sm-0">
																		<input type="text" name="street" class="form-control form-control-user" placeholder="Street" required autocomplete="off">
																	</div>
																	<div class="col-sm-4 mb-3 mb-sm-0">
																		<input type="text" name="city" class="form-control form-control-user" placeholder="City" required autocomplete="off">
																	</div>
																	<div class="col-sm-4 mb-3 mb-sm-0">
																		<input type="text" name="state" class="form-control form-control-user" placeholder="State" required autocomplete="off">
																	</div>
																</div>
																<div class="form-group row">
																	<div class="col-sm-6 mb-3 mb-sm-0">
																		<select name="userGender" class="form-control" required>
																			<option value="Male" selected>Male</option>
																			<option value="Female">Female</option>
																			<option value="Others">Others</option>
																		</select>
																	</div>
																	<div class="col-sm-6 mb-3 mb-sm-0">
																		<input type="date" class="form-control" placeholder="Date of Birth" name="userDOB" max="<?php echo date('Y-m-d', strtotime('-16 year')); ?>" required autocomplete="off">
																	</div>
																</div>
																<button type="submit" class="btn btn-primary btn-user btn-block">Register Account</button>
														</form>
														<hr>
														<div class="text-center">
																<a class="small" href="forgot-password.php">Forgot Password?</a>
														</div>
														<div class="text-center">
																<a class="small" href="login.php">Already have an account? Login!</a>
														</div>
												</div>
										</div>
								</div>
						</div>
				</div>

		</div>

		<!-- Bootstrap core JavaScript-->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

		<!-- Core plugin JavaScript-->
		<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

		<!-- Custom scripts for all pages-->
		<script src="js/sb-admin-2.min.js"></script>

</body>

</html>