<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
  <hr class="sidebar-divider my-0">

  <li class="nav-item active">
    <a class="nav-link" href="index.php">
      <i class="fas fa-fw fa-tachometer-alt"></i>
      <span>Dashboard</span></a>
  </li>

  <hr class="sidebar-divider">

  <div class="sidebar-heading">
    Interface
  </div>

  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#incomeCollapseMenu"
          aria-expanded="true" aria-controls="incomeCollapseMenu">
          <i class="fas fa-fw fa-dollar-sign"></i>
          <span>Income</span>
      </a>
      <div id="incomeCollapseMenu" class="collapse <?php echo (isset($section) === true AND $section == 'income') ? 'show':null; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">Your Income</h6>
              <a class="collapse-item <?php echo (isset($page) === true AND $page == 'add-income') ? 'active':null; ?>" href="add-income.php">Add Income</a>
              <a class="collapse-item <?php echo (isset($page) === true AND $page == 'view-income') ? 'active':null; ?>" href="view-income.php">View Incomes</a>
          </div>
      </div>
  </li>

  <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#expenseCollapseMenu"
          aria-expanded="true" aria-controls="expenseCollapseMenu">
          <i class="fas fa-fw fa-donate"></i>
          <span>Expense</span>
      </a>
      <div id="expenseCollapseMenu" class="collapse <?php echo (isset($section) === true AND $section == 'expense') ? 'show':null; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">Your Expense</h6>
              <a class="collapse-item <?php echo (isset($page) === true AND $page == 'add-expense') ? 'active':null; ?>" href="add-expense.php">Add Expense</a>
              <a class="collapse-item <?php echo (isset($page) === true AND $page == 'view-expense') ? 'active':null; ?>" href="view-expense.php">View Expenses</a>
          </div>
      </div>
  </li>

  <li class="nav-item <?php echo (isset($section) === true AND $section == 'summary') ? 'active':null; ?>">
    <a class="nav-link" href="summary.php">
        <i class="fas fa-fw fa-chart-line"></i>
        <span>Summary</span>
    </a>
  </li>

  <hr class="sidebar-divider">

  <li class="nav-item">
    <a class="nav-link" href="logout.php">
        <i class="fas fa-fw fa-sign-out-alt"></i>
        <span>Logout</span>
    </a>
  </li>

  <!-- Divider -->
  <hr class="sidebar-divider d-none d-md-block">

  <!-- Sidebar Toggler (Sidebar) -->
  <div class="text-center d-none d-md-inline">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
  </div>

</ul>