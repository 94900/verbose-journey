<!-- alert -->
  <?php if(Session::exists('successMessage') === true AND is_null(Session::get('successMessage')) === false AND empty(Session::get('successMessage')) === false){ ?>
    <div class="m-l-25 m-r--38 m-lr-0-xl">
      <div class="row">
        <div class="col-lg-12">
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Alert:</strong>
            <?php echo Session::flash('successMessage'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>
        <div class="col-lg-5"></div>
      </div>
    </div>
  <?php } elseif(isset($errorMessages) === true AND is_null($errorMessages) === false AND ( (is_array($errorMessages) === true AND count($errorMessages) > 0) OR (is_string($errorMessages) === true AND strlen($errorMessages) > 0))){ ?>
    <div class="m-l-25 m-r--38 m-lr-0-xl">
      <div class="row">
        <div class="col-lg-12">
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Alert:</strong>
            <?php
              if(is_array($errorMessages) === true){
                if(count($errorMessages) > 0){
                  foreach($errorMessages as $e){
                    echo $e ."<br/>";
                  }
                }
              } else {
                echo $errorMessages;
              }
            ?>
            <button type="button" class="close d-inline-block mt-2" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>
        <div class="col-lg-5"></div>
      </div>
    </div>
  <?php } ?>
  <!-- //alert -->