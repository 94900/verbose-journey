<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo Config::get('appData/name/full'); ?> 2021</span>
        </div>
    </div>
</footer>