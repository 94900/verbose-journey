<?php
	session_start();

	defined('ENVIRONMENT') ? null : define('ENVIRONMENT', 'DEVELOPMENT');
	defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
	defined('FOLDER_PATH') ? null : define('FOLDER_PATH', 'Web Owls'.DS.'Expense Tracker'.DS);
	if(ENVIRONMENT == 'DEVELOPMENT'){
		define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].DS.FOLDER_PATH);
		define('SERVER_PATH', $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'].DS.FOLDER_PATH);
	} elseif(ENVIRONMENT == 'DEPLOYMENT'){
		define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].DS);
		define('SERVER_PATH', $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'].DS);
	}

	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Cache-Control: no-cache");
	header("Pragma: no-cache");

	spl_autoload_register(function($class){
		require_once 'classes/' . strtolower($class) . '.php';
	});

	date_default_timezone_set("Asia/Karachi");

	spl_autoload_register(function($class){
		require_once ROOT_PATH.'core'.DS.'classes'.DS.strtolower($class) . '.php';
	});

	$user = new Contributor();

	function alert($alert = null){
		if(!is_null($alert)){
			echo "<script>alert('".$alert."');</script>";
		} else {
			echo "<script>alert('Oops... An unknown error occurred!');</script>";
		}
	}

	$errorFlag 		= (bool)false;
	$errorMessages 	= array();
	$successMessage	= null;
	$ajaxResponse = (object)[
		'status'					=> (bool)false,
		'errorMessage'		=> null,
		'successMessage'	=> null,
		'data'						=> array()
	];
?>