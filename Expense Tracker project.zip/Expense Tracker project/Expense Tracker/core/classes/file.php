<?php
  class File {
    public static function getExtension($fileName = null){
      return strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    }
  }
?>