<?php
  class Role extends custom_error {
    
    private $_db          = null,
            $_table       = null;

    public function __construct(){
      $this->_db = DB::getInstance();
      $this->_table = (object)[
        'name'    => 'user_roles',
        'fields'  => '`role_id` as `id`, `title`, `table`'
      ];
    }

    public function find($roleID = null){
      $dem = 'Failed to find user role.';
      if(is_null($roleID) === false){
        $findRole = $this->_db->get($this->_table->fields, $this->_table->name, '`role_id` = ?', array($roleID));
        if($findRole->errorStatus() === false){
          if($findRole->dataCount() == 1){
            // user role found
            return $findRole->getFirstResult();
          } else {
            // user role not found
            $this->setError($dem);
            return null;
          }
        } else {
          // query processing error
          $this->setError($dem);
          return null;
        }
      } else {
        $this->setError($dem);
        return null;
      }
    }

    public function findByTitle($roleTitle = null){
      $dem = 'Failed to find user role.';
      if(is_string($roleTitle) === true){
        $findRole = $this->_db->get($this->_table->fields, $this->_table->name, '`title` = ?', array($roleTitle));
        if($findRole->errorStatus() === false){
          if($findRole->dataCount() == 1){
            // user role found
            return $findRole->getFirstResult();
          } else {
            // user role not found
            $this->setError($dem);
            return null;
          }
        } else {
          // query processing error
          $this->setError($dem);
          return null;
        }
      } else {
        $this->setError($dem);
        return null;
      }
    }
  }

?>