<?php
  class Address extends custom_error {
    private $_db = null;

    private $_data        = null,
            $_table       = null;

    public function __construct(){
      $this->_db = DB::getInstance();
      $this->_table = (object)[
        'name'      => 'addresses',
        'fields'    => '`address_id`, `country`, `state`, `province`, `city`, `street_primary`'
      ];
    }

    public function create($state = null, $city = null, $street = null){
      // at least one entity should not be null
      $dem = 'Failed to create address.';
      if(is_null($state) === false OR is_null($city) == null OR is_null($street) === false){
        $tmpAddressID = Hash::unique();
        $createAddress = $this->_db->insert($this->_table->name, array(
          'address_id'       => $tmpAddressID,
          'country'         => 'INDIA',
          'state'           => strtoupper($state),
          'province'        => null,
          'city'            => strtoupper($city),
          'street_primary'  => strtoupper($street)
        ));
        if($createAddress->errorStatus() === false){
          // no error
          return $tmpAddressID;
        } else {
          // error
          $this->setError($dem);
          return false;
        }
      }
    }

    private function _create($country = null, $state = null, $province = null, $city = null, $street = null){
      // at least one entity should not be null
      $dem = 'Failed to create address.';
      if(is_null($country) === false OR is_null($state) === false OR is_null($province) === false OR is_null($city) == null OR is_null($street) === false){
        $tmpAddressID = Hash::unique();
        $createAddress = $this->_db->insert($this->_table->name, array(
          'address_id'       => $tmpAddressID,
          'country'         => $country,
          'state'           => $state,
          'province'        => $province,
          'city'            => $city,
          'street_primary'  => $street
        ));
        if($createAddress->errorStatus() === false){
          // no error
          return $tmpAddressID;
        } else {
          // error
          $this->setError($dem);
          return false;
        }
      }
    }

    public function find($addressID = null, $type = null){
      if(is_null($addressID) === false){
        switch(strtoupper($type)){
          case 'ACTIVE':
            $type = 1;
          break;
          default:
            $type = 1;
          break;
        }
        $findAddress = $this->_db->get($this->_table->fields, $this->_table->name, '`address_id` = ?', array($addressID));
        if($findAddress->errorStatus() === false AND $findAddress->dataCount() == 1){
          $tmpAddress = $findAddress->getFirstResult();
          return (object)[
            'country'   => $tmpAddress->country,
            'state'     => $tmpAddress->state,
            'province'  => $tmpAddress->province,
            'city'      => $tmpAddress->city,
            'street'    => $tmpAddress->street_primary,
          ];
        } else {
          return null;
        }
      } else {
        return null;
      }
    }

    public function search($country = null, $state = null, $province = null, $city = null, $street = null){
      // at least one entity should not be null
      $dem = 'Failed to search address.';
      if(is_null($country) === false OR is_null($state) === false OR is_null($province) === false OR is_null($city) == null OR is_null($street) === false){
        $findAddress = $this->_db->get('`address_id`', $this->_table->name, '`country` = ? AND `state` = ? AND `province` = ? AND `city` = ? AND `street_primary` = ?', array($country, $state, $province, $city, $street));
        if($findAddress->errorStatus() === false){
          // no error
          if($findAddress->dataCount() == 1){
            $tmpAddress = $findAddress->getFirstResult();
            return $tmpAddress->address_id;
          } else {
            return true;
          }
        } else {
          // error
          $this->setError($dem);
          return false;
        }
      }
    }

    // parser
    private function __parseAddressData($data = null){
      if(is_null($data) === false AND is_object($data) === true){
        $data = (object)$data;
        if(isset($data->country) === true AND isset($data->state) === true AND isset($data->province) === true AND isset($data->city) === true AND isset($data->street) === true){
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }

  }
?>