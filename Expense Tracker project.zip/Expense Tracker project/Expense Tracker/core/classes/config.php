<?php
	class Config {
		private static $config = array(
			'mysql'		=> array(
				'host'				=> '127.0.0.1',
				'username'		=> 'root',
				'password'		=> '',
				'db'					=> 'wo_exp_tracker'
			),
			'session'	=> array(
				'name'				=> 'WO_EXP_TRACKER',
				'token_name'	=> 'token'
			),
			'appData'				=> array(
				'name'					=> array(
					'abbr'						=> 'Exp-Tracker',
					'accr'						=> 'ET',
					'full'						=> 'Expense Tracker'
				),
				'description'		=> array(
					'brief'						=> 'Track your expenses.',
					'detail'					=> ''
				),
				'keywords'			=> array('ET', 'Expense Tracker'),
				'generator'			=> 'Web Owls',
				'organization'	=> 'Web Owls',
				'author'				=> 'Nissi Hosanee'
			)
		);

		private static $configLive = array(
			'mysql'		=> array(
				'host'				=> 'Localhost',
				'username'		=> 'uuymwggsyds0q',
				'password'		=> 'MRMP@2001',
				'db'					=> 'dbg0lfbsfdin3n'
			),
			'session'	=> array(
				'name'				=> 'WO_EXP_TRACKER',
				'token_name'	=> 'token'
			)
		);

		public static function get($path = null){
			if($path){
				$value	= (ENVIRONMENT == 'DEPLOYMENT') ? self::$configLive: self::$config;
				$path 	= explode('/', $path);
				foreach($path as $bit){
					if(isset($value[$bit])){
						$value = $value[$bit];
					}
				} return $value;
			} return false;
		}
	}
?>