<?php
  class Income extends custom_error {
    
    private $_db          = null,
            $_table       = null;

    public function __construct(){
      $this->_db = DB::getInstance();
      $this->_table = (object)[
        'name'    => 'incomes',
        'fields'  => '`income_id` as `id`, `title`, `amount`, `added_on` as `date`'
      ];
    }

    public function find($incomeID = null){
      $dem = 'Failed to find income entry.';
      if(is_null($incomeID) === false){
        $income = $this->_db->get($this->_table->fields, $this->_table->name, '`income_id` = ?', array($incomeID));
        if($income->errorStatus() === false){
          if($income->dataCount() == 1){
            // income found
            return $income->getFirstResult();
          } else {
            // income not found
            $this->setError($dem);
            return null;
          }
        } else {
          // query processing error
          $this->setError($dem);
          return null;
        }
      } else {
        $this->setError($dem);
        return null;
      }
    }

    public function getAll(){
      $dem = 'Failed to find income history.';
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`income_status` = ?', array(1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // income history found
          return $find->getResults();
        } else {
          // income history not found
          $this->setError($dem);
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function getContributorIncomes($contributorID = null){
      $dem = 'Failed to find income history.';
      if(is_string($contributorID) === false){
        $this->setError($dem);
        return false;
      }
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ? AND `income_status` = ?', array($contributorID, 1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // income history found
          return $find->getResults();
        } else {
          // income history not found
          $this->setError('You do not have any income history right now.');
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function getMonthlyContributorIncomes($contributorID = null, $date = null){
      $dem = 'Failed to find income history.';
      if(is_string($contributorID) === false OR is_string($date) === false){
        $this->setError($dem);
        return false;
      }
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ? AND year(`added_on`) = ? AND month(`added_on`) = ? AND `income_status` = ?', array($contributorID, date('Y', strtotime($date)), date('m', strtotime($date)), 1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // income history found
          return $find->getResults();
        } else {
          // income history not found
          $this->setError('You do not have any income history right now.');
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function findByName($name = null){
      $dem = 'Failed to find category.';
      if(is_null($name) === false){
        $expense = $this->_db->get($this->_table->fields, $this->_table->name, '`name` = ?', array($name));
        if($expense->errorStatus() === false){
          if($expense->dataCount() == 1){
            // income found
            return $expense->getFirstResult();
          } else {
            // income not found
            $this->setError('You do not have any such title.');
            return null;
          }
        } else {
          // query processing error
          $this->setError($dem);
          return false;
        }
      } else {
        $this->setError($dem);
        return false;
      }
    }

  }

?>