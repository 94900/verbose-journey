<?php
	class User extends Person {
		// internal objects
		protected $_userType 					= null,
							$_allowedUserTypes 	= null,
							$_userId 						= null,
							$_isLoggedIn 				= false;
		// external object
		protected $_role 							= null;
				
		public function __construct($type = null){
			parent::__construct();
			$this->_role = new Role();
			$this->_allowedUserTypes = array('WELL-WISHER', 'RECEIVER');
			if(is_null($type) === false){
				$this->_userType = $type;
				$checkUser = $this->checkLogin();
				if($checkUser !== false AND isset($checkUser->status) === true AND $checkUser->status === true){
					// user is logged in
					if($this->_verifyLoginUser() === true){
						$tmpUserSession = Session::get(Config::get('session/name'));
						$tmpUser = $this->_find($tmpUserSession->id);
						if(is_null($tmpUser) === false AND is_object($tmpUser) === true){
							// user found successfully, (also need to verify the role)
							$tmpUser = (object)$tmpUser;
							$this->_setUserData($tmpUser, 'ALL');
							$person = $this->_findP($tmpUser->person);
							if(is_null($person) === false){
								$this->_setPersonData($person);
							}
							// set address
							$tmpUserAddress = $this->_findAddress($tmpUser->id);
							if(is_object($tmpUserAddress) === true){
								$this->_setAddress($tmpUserAddress);
							}
							$this->setLogin(true);
						} else {
							// failed to find the logged in user
							$this->logout();
							Redirect::to('home');
						}
					}
				}
			}
		}

		protected function _setUserData($data = null, $type = null){
			if(is_null($data) === false){
				switch(strtoupper($type)){
					case 'PUBLIC':
						$this->_setPublicData($data);
					break;
					case 'PRIVATE':
						$this->_setPrivateData($data);
					break;
					case 'ALL':
						$this->_setPublicData($data);
						$this->_setPrivateData($data);
					break;
					default:
						//
					break;
				}
			}
		}
		private function _setPublicData($data = null){
			if(is_null($data) === false){
				if(isset($data->email) === true){
					$this->_data->public->email = $data->email;
				}
				if(isset($data->contact) === true){
					$this->_data->public->contact = $data->contact;
				}
				if(isset($data->phone) === true){
					$this->_data->public->phone = $data->phone;
				}
				if(isset($data->gender) === true){
					$this->_data->public->gender = $data->gender;
				}
				if(isset($data->dob) === true){
					$this->_data->public->dob = $data->dob;
				}
				if(isset($data->registrationDate) === true){
					$this->_data->public->registrationDate = $data->registrationDate;
				}
				if(isset($data->hFile) === true){
					$this->_data->public->hFile = $data->hFile;
				}
			}
		}
		private function _setPrivateData($data = null){
			if(is_null($data) === false){
				if(isset($data->id) === true){
					$this->_data->private->userID = $data->id;
				}
				if(isset($data->privateID) === true){
					$this->_data->private->privateID = $data->privateID;
				}
				if(isset($data->person) === true){
					$this->_data->private->personID = $data->person;
				}
				if(isset($data->token) === true){
					$this->_data->private->token = $data->token;
				}
				if(isset($data->password) === true){
					$this->_data->private->password = $data->password;
				}
			}
		}
		private function _setAddress($data = null){
			if(isset($data->street) === true AND isset($data->city) === true AND isset($data->state) === true AND isset($data->country) === true){
				$this->_data->public->address = $data;
			}
		}

		// strt abstract methods
		protected function _setPersonData($data = null) : void {
			if(is_null($data) === false){
				if(isset($data->name) === true){
					$this->_data->public->name = $data->name;
				}
				if(isset($data->cnic) === true){
					$this->_data->public->cnic = $data->cnic;
				}
			}
		}
		protected function _getPrivateData($key = null):string {
			if(is_null($key) === false){
				return (isset($this->_data->private->$key) === true) ? $this->_data->private->$key:null;
			}
		}
		public function getData($key = null){
			if($this->isLoggedIn() === true AND is_null($key) === false){
				return (isset($this->_data->public->$key) === true) ? $this->_data->public->$key:null;
			}
		}
		// end abstract methods

		private function _find($userID = null, $type = null){
			$dem = 'User not found.';
			if(is_null($userID) === false){
				switch(strtoupper($type)){
					case 'ACTIVE':
						$type = 1;
					break;
					default:
						$type = 1;
					break;
				}
				$findUser = $this->_db->get('`user_id`, `person_id`, `email`, `phone`, `contact`, `gender`, `dob`, `token`, `password`, `registered_on`', 'users', '`user_id` = ? AND `account_status` = ?', array($userID, $type));
				if($findUser->errorStatus() === false AND $findUser->dataCount() == 1){
					$tmpUser = $findUser->getFirstResult();
					return (object)[
						'id'									=> $tmpUser->user_id,
						'person'							=> $tmpUser->person_id,
						'email'								=> $tmpUser->email,
						'phone'								=> $tmpUser->phone,
						'contact'							=> $tmpUser->contact,
						'gender'							=> $tmpUser->gender,
						'dob'									=> $tmpUser->dob,
						'token'								=> $tmpUser->token,
						'password'						=> $tmpUser->password,
						'role'								=> null,
						'registrationDate'		=> $tmpUser->registered_on
					];
				} else {
					$this->setError($dem);
					return null;
				}
			} else {
				$this->setError($dem);
				return null;
			}
		}

		protected function find($userID = null, $type = null){
			$dem = 'User not found.';
			if(is_null($userID) === false){
				switch(strtoupper($type)){
					case 'ACTIVE':
						$type = 1;
					break;
					default:
						$type = 1;
					break;
				}
				$findUser = $this->_db->get('`user_id`, `person_id`, `email`, `contact`', 'users', '`user_id` = ? AND `account_status` = ?', array($userID, $type));
				if($findUser->errorStatus() === false AND $findUser->dataCount() == 1){
					$tmpUser = $findUser->getFirstResult();
					return (object)[
						'id'				=> $tmpUser->user_id,
						'person'		=> $tmpUser->person_id,
						'name'			=> null,
						'email'			=> $tmpUser->email,
						'contact'		=> $tmpUser->contact,
						'role'			=> null
					];
				} else {
					$this->setError($dem);
					return null;
				}
			} else {
				$this->setError($dem);
				return null;
			}
		}

		protected function findByEmail($email = null, $type = null){
			$dem = 'User not found.';
			$tmpResponse = (object)[
				'status'		=> false,
				'data'			=> null,
				'message'		=> (object)[
					'success'			=> null,
					'error'				=> null
				]
			];
			if(is_null($email) === false){
				switch(strtoupper($type)){
					case 'ACTIVE':
						$type = 1;
					break;
					default:
						$type = 1;
					break;
				}
				$findUser = $this->_db->get('`user_id`, `email`, `token`, `password`, `role_id`', 'users', '`email` = ? AND `account_status` = ?', array($email, $type));
				if($findUser->errorStatus() === false AND $findUser->dataCount() == 1){
					$tmpUser = $findUser->getFirstResult();
					$tmpResponse->status = true;
					$tmpResponse->data = (object)[
						'id'				=> $tmpUser->user_id,
						'email'			=> $tmpUser->email,
						'token'			=> $tmpUser->token,
						'password'	=> $tmpUser->password,
						'role'			=> $this->_role->find($tmpUser->role_id)
					];
					return $tmpResponse;
				} else {
					$tmpResponse->message->error = $dem;
					return $tmpResponse;
				}
			} else {
				$tmpResponse->message->error = $dem;
				return null;
			}
		}

		protected function _isUsernameAvailable($username = null){
			$dem = 'Failed to check username availability.';
			if(is_null($username) === false){
				$checkUsername = $this->_db->get('`username`', '`users`', '`username` = ?', array($username));
				if($checkUsername->errorStatus() === false){
					if($checkUsername->dataCount() == 0){
						return true;
					} else {
						return false;
					}
				} else {
					$this->setError($dem);
					return false;
				}
			} else {
				return false;
			}
		}

		protected function _isPhoneUnique($phone = null){
			$dem = 'Failed to check phone number availability.';
			if(is_null($phone) === false){
				$checkPhone = $this->_db->get('`phone`', '`users`', '`phone` = ?', array($phone));
				if($checkPhone->errorStatus() === false){
					if($checkPhone->dataCount() == 0){
						return true;
					} else {
						$this->setError('This phone number is already in use.');
						return false;
					}
				} else {
					$this->setError($dem);
					return false;
				}
			} else {
				return false;
			}
		}

		protected function _isEmailUnique($email = null){
			$dem = 'Failed to check email availability.';
			if(is_null($email) === false){
				$checkEmail = $this->_db->get('`email`', '`users`', '`email` = ?', array($email));
				if($checkEmail->errorStatus() === false){
					if($checkEmail->dataCount() == 0){
						return true;
					} else {
						$this->setError('This email is already in use.');
						return false;
					}
				} else {
					$this->setError($dem);
					return false;
				}
			} else {
				return false;
			}
		}

		public function isAllowedUserType($type = null){
			return (in_array(strtoupper($type), $this->_allowedUserTypes) === true) ? true:false;
		}

		public function login($email = null, $password = null){
			$dem = 'Failed to login.';
			if(is_null($email) === false AND is_null($password) === false){
				$tmpUser = $this->findByEmail($email);
				if(is_object($tmpUser) === true AND isset($tmpUser->status) === true AND $tmpUser->status === true){
					// user found, i.e. email is correct
					if($tmpUser->data->password == Hash::make($password.$tmpUser->data->token)){
						// password matched
						if($this->_putUserSession($tmpUser->data->role->title, $tmpUser->data->id) === true){
							return true;
						} else {
							$this->setError($dem);
							return false;
						}
					} else {
						// password didn't match
						$this->setError($dem.' Password is incorrect.');
						return false;
					}
				} else {
					// some error occurred
					if(isset($tmpUser->message->error) === true AND is_null($tmpUser->message->error) === false){
						// error message exists
						$this->setError($tmpUser->message->error);
						return false;
					} else {
						// error message doesn't exist
						$this->setError($dem);
						return false;
					}
				}
			} else {
				$this->setError($dem);
				return null;
			}
		}

		public function logout(){
			if(Session::exists(Config::get('session/name')) === true){
				Session::delete(Config::get('session/name'));
				return true;
			} else {
				session_destroy();
				return true;
			}
			return false;
		}

		protected function _putUserSession($type = null, $userID = null){
      $defaultErrorMessage = 'Failed to login.';
      if(is_null($type) === false AND is_null($userID) === false){
        if(Session::exists(Config::get('session/name')) === true){
          // session already exists with this name
          $tmpUserSession = Session::get(Config::get('session/name'));
          if($tmpUserSession->type != $type OR $tmpUserSession->id != $userID){
            // user is different
            if(Session::put(Config::get('session/name'), (object)[
              'id'        => $userID,
              'type'      => $type
            ]) === true){
              return true;
            } else {
              $this->setError($defaultErrorMessage);
              return false;
            }
          }
        } else {
          if(Session::put(Config::get('session/name'), (object)[
            'id'        => $userID,
            'type'      => $type
          ]) === true){
            return true;
          } else {
            $this->setError($defaultErrorMessage);
            return false;
          }
        }
      } else {
        $this->setError($defaultErrorMessage);
        return false;
      }
    }

		protected function setLogin($loginStatus = false){
			if(is_bool($loginStatus) === true){
				$this->_isLoggedIn = $loginStatus;
			} else {
				$this->_isLoggedIn = false;
			}
		}

		public function isLoggedIn(){
			return (is_bool($this->_isLoggedIn) === true) ? $this->_isLoggedIn:false;
		}

		private function _verifyLoginUser(){
			$checkUser = $this->checkLogin();
			if(isset($checkUser->status) === true AND $checkUser->status === true AND isset($checkUser->user) === true){
				if(strtoupper($checkUser->user) == $this->_userType){
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function checkLogin(){
			$tmpUserSession = Session::get(Config::get('session/name'));
			if(is_null($tmpUserSession) === false AND isset($tmpUserSession->type) === true AND isset($tmpUserSession->id) === true){
				if(is_null($tmpUserSession->type) === false AND is_null($tmpUserSession->id) === false){
					return (object)[
						'status'		=> true,
						'user'			=> $tmpUserSession->type
					];
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function resetPassword($userEmail = null){
			$dem = 'Failed to reset password.';
			if(is_string($userEmail) === true){
				$findUser = $this->findByEmail($userEmail);
				if(is_object($findUser) === true AND isset($findUser->data) === true AND is_object($findUser->data) === true){
					$newPassword = uniqid();
					$newHashedPassword = Hash::make($newPassword.$findUser->data->token);
					$resetPassword = $this->_db->update('users', '`password` = ?', '`email` = ?', array($newHashedPassword, $userEmail));
					if($resetPassword->errorStatus() === false){
						// pasword has been changed, email this new password
						$emailTo = $userEmail;
						$emaliSubject = "Password Reset @ Ekrupay";
						$emailHeaders = "MIME-Version: 1.0" . "\r\n";
						$emailHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";
						$emailHeaders .= 'From: <noreply@ekrupay.com>' . "\r\n";
						// $headers .= 'Cc: myboss@example.com' . "\r\n";
						$emailMessage = "Your password has been changed. The new login crednetials are as below.<br/>";
						$emailMessage .= "<b>Email:</b> {$userEmail}<br/>";
						$emailMessage .= "<b>Password:</b> {$newPassword}<br/>";
						$emailMessage .= "<b>Note:</b> Password is case sensitive.";
						if(@mail($emailTo, $emaliSubject, $emailMessage, $emailHeaders) === true){
							return true;
						} else {
							$this->setError($dem);
							return false;
						}
					} else {
						$this->setError($dem);
						return false;
					}
				} else {
					$this->setError('Account not found.');
					return false;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		// receivers
		public function getReceiverBySID($SID = null){
			$dem = 'Faild to find non-sponsered receivers.';
			if(is_null($SID) === true){
				$this->setError($dem);
				return false;
			}
			$find = $this->_db->get('`receiver_id` as `id`, `secondary_id` as `SID`', 'receivers', '`secondary_id` = ?', array($SID));
			if($find->errorStatus() === false AND $find->dataCount() == 1){
				return $find->getFirstResult();
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function getNonSponseredReceivers(){
			$dem = 'Faild to find non-sponsered receivers.';
			$find = $this->_db->get('`receiver_id` as `id`, `secondary_id` as `SID`', 'receivers', '`is_sponsered` = ?', array(0));
			if($find->errorStatus() === false){
				if($find->dataCount() > 0){
					$tmpReceivers = array();
					foreach($find->getResults() as $nsr){
						array_push($tmpReceivers, $nsr);
					}
					if(is_array($tmpReceivers) === true AND count($tmpReceivers) > 0){
						return $tmpReceivers;
					} else {
						$this->setError($dem);
						return false;
					}
				} else {
					$this->setError('There is not any non-sponsered receiver yet.');
					return null;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		// address
		protected function _findAddress($userID = null){
			if(is_string($userID) === true){
				$findUserAddress = $this->_db->get('`country`, `state`, `city`, `street`', 'users', '`user_id` = ?', array($userID));
				if($findUserAddress->errorStatus() === false AND $findUserAddress->dataCount() == 1){
					return $findUserAddress->getFirstResult();
				} else {
					// error in quer processing/data-count
				}
			}
		}
		protected function _addUserAddress($data = null, $userID = null){
			$dem = 'Failed to add address details.';
			if(is_string($userID) === true AND $this->__parseAddressData($data) === true){
				$addAddress = $this->_address->create($data->state, $data->city, $data->street);
				if($addAddress !== false){
					$addUserAddress = $this->_db->insert('user_addresses', array(
						'ua_id'				=> Hash::unique(),
						'user_id'			=> $userID,
						'address_id'	=> $addAddress,
						'ua_status'		=> 1
					));
					if($addUserAddress->errorStatus() === false){
						return true;
					} else {
						$this->setError($dem);
						return false;
					}
				} else {
					$this->setError($dem);
					return false;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		protected function _updateAddress($userID = null, $address = null){
      $dem = 'Failed to update address.';
      if(is_null($userID) === false AND $this->__parseAddressData($address) === true){
        $country = 'India'; $state = $address->state; $province = null; $city = $address->city; $street = $address->street;
        $update = $this->_db->update('users', '`state` = ?, `city` = ?, `street` = ?', '`user_id` = ?', array($state, $city, $street, $userID));
				if($update->errorStatus() === false){
					return true;
				} else {
					$this->setError($dem);
					return false;
				}
      } else {
        $this->setError($dem);
        return false;
      }
    }

		// data parsers
		protected function __parseAddressData($data = null){
      if(is_null($data) === false AND is_object($data) === true){
        $data = (object)$data;
        if(isset($data->state) === true AND isset($data->city) === true AND isset($data->street) === true){
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
	}
?>