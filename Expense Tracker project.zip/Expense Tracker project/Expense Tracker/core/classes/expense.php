<?php
  class Expense extends custom_error {
    
    private $_db          = null,
            $_table       = null;

    public function __construct(){
      $this->_db = DB::getInstance();
      $this->_table = (object)[
        'name'    => 'expenses',
        'fields'  => '`expense_id` as `id`, `title`, `amount`, `added_on` as `date`'
      ];
    }

    public function find($expenseID = null){
      $dem = 'Failed to find expense entry.';
      if(is_null($expenseID) === false){
        $expense = $this->_db->get($this->_table->fields, $this->_table->name, '`expense_id` = ?', array($expenseID));
        if($expense->errorStatus() === false){
          if($expense->dataCount() == 1){
            // expense found
            return $expense->getFirstResult();
          } else {
            // expense not found
            $this->setError($dem);
            return null;
          }
        } else {
          // query processing error
          $this->setError($dem);
          return null;
        }
      } else {
        $this->setError($dem);
        return null;
      }
    }

    public function getAll(){
      $dem = 'Failed to find expense history.';
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`expense_status` = ?', array(1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // expense history found
          return $find->getResults();
        } else {
          // expense history not found
          $this->setError($dem);
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function getContributorExpenses($contributorID = null){
      $dem = 'Failed to find expense history.';
      if(is_string($contributorID) === false){
        $this->setError($dem);
        return false;
      }
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ? AND `expense_status` = ?', array($contributorID, 1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // expense history found
          return $find->getResults();
        } else {
          // expense history not found
          $this->setError('You do not have any expense history right now.');
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function getMonthlyContributorExpenses($contributorID = null, $date = null){
      $dem = 'Failed to find expense history.';
      if(is_string($contributorID) === false OR is_string($date) === false){
        $this->setError($dem);
        return false;
      }
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ? AND year(`added_on`) = ? AND month(`added_on`) = ? AND `expense_status` = ?', array($contributorID, date('Y', strtotime($date)), date('m', strtotime($date)), 1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // expense history found
          return $find->getResults();
        } else {
          // expense history not found
          $this->setError('You do not have any expense history right now.');
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
    }

    public function getDailyExpense($contributorID = null, $date = null){
			$dem = 'Failed to find expense history.';
      if(is_string($contributorID) === false OR is_string($date) === false){
        $this->setError($dem);
        return false;
      }
      $find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ? AND year(`added_on`) = ? AND month(`added_on`) = ? AND day(`added_on`) = ? AND `expense_status` = ?', array($contributorID, date('Y', strtotime($date)), date('m', strtotime($date)), date('d', strtotime($date)), 1));
      if($find->errorStatus() === false){
        if($find->dataCount() > 0){
          // expense history found
          $totalExpenseAmount = 0;
          foreach($find->getResults() as $exp){
            $totalExpenseAmount += $exp->amount;
          }
          return $totalExpenseAmount;
        } else {
          // expense history not found
          $this->setError('You do not have any expense history right now.');
          return null;
        }
      } else {
        // query processing error
        $this->setError($dem);
        return null;
      }
		}

  }

?>