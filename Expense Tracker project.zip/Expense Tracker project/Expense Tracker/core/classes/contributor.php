<?php
	class Contributor extends User {
		// internal objects
		private $_type 		= 'WO_EXP_TRACKER_CONTRIBUTOR',
						$_table 	= null,
						$_income 	= null,
						$_expense = null;
		// external objects

		public function __construct($BAWA_G = false){
			$this->_table = (object)[
				'name'		=> 'contributors',
				'fields'	=> '`contributor_id` as `id`, `user_id` as `userID`'
			];
			if($BAWA_G === false){
				parent::__construct($this->_type);
				if($this->isLoggedIn() === true){
					$this->_income 	= new Income();
					$this->_expense = new Expense();
					$findContributor = $this->_db->get($this->_table->fields, $this->_table->name, '`user_id` = ?', array($this->_getPrivateData('userID')));
					if($findContributor->errorStatus() === false AND $findContributor->dataCount() == 1){
						$tmpContributor = $findContributor->getFirstResult();
						$this->_setUserData((object)[
							'privateID'			=> $tmpContributor->id
						], 'PRIVATE');
					}
				}
			} else {
				parent::__construct($this->_type);
			}
		}

		public function findContributor($contributorID = null){
			$dem = 'Failed to find contributors';
			if(is_string($contributorID) === false){
				$this->setError($dem);
				return false;
			}
			$find = $this->_db->get($this->_table->fields, $this->_table->name, '`contributor_id` = ?', array($contributorID));
			if($find->errorStatus() === false AND $find->dataCount() == 1){
				$tmpContributor = $find->getFirstResult();
				$findUser = $this->_db->get('`user_id` as `id`, `person_id` as `PID`, `phone`, `email`, `gender`, `dob`, `profile_pic` as `profilePic`, `street`, `city`, `state`,  `registered_on` as `registeredOn`', '`users`','`user_id` = ?', array($tmpContributor->userID));
				if($findUser->errorStatus() === true OR $findUser->dataCount() == 0){
					$this->setError($dem);
					return false;
				}
				$tmpUser = $findUser->getFirstResult();
				$tmpPerson = $this->_findP($tmpUser->PID);
				if(is_object($tmpPerson) === false){
					$this->setError($dem);
					return false;
				}
				$tmpType = 'Not Specified';
				if(isset($tmpContributor->type) === true AND $tmpContributor->type != 0){
					$tmpType = ($tmpContributor->type == 1) ? 'Golden-Heart':'Red-Heart';
				}
				return (object)[
					'id'						=> $tmpUser->id,
					'name'					=> $tmpPerson->name,
					'email'					=> $tmpUser->email,
					'phone'					=> $tmpUser->phone,
					'gender'				=> $tmpUser->gender,
					'dob'						=> $tmpUser->dob,
					'profilePic'		=> $tmpUser->profilePic,
					'hFile'					=> $tmpContributor->hFile,
					'address'				=> (empty($tmpUser->street) === false) ? $tmpUser->street.', '.$tmpUser->city.', '.$tmpUser->state:'N/A',
					'registeredOn'	=> $tmpUser->registeredOn
				];
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function getAll(){
			$dem = 'Failed to find contributors';
			$find = $this->_db->get('`contributor_id` as `id`', $this->_table->name, '`contributor_status` = ?', array(1));
			if($find->errorStatus() === false AND $find->dataCount() > 0){
				$tmpContributors = array();
				foreach($find->getResults() as $tmpContributor){
					$contributor = $this->findContributor($tmpContributor->id);
					array_push($tmpContributors, $contributor);
				}
				if(is_array($tmpContributors) === false OR count($tmpContributors) <= 0){
					$this->setError($dem);
					return false;
				}
				return $tmpContributors;
			} else {
				$this->setError($dem);
				return false;
			}
		}

		private function _findByUID($userID = null, $type = null){
			$dem = 'Well-wisher not found.';
			$tmpResponse = (object)[
				'status'		=> false,
				'data'			=> null,
				'message'		=> (object)[
					'success'			=> null,
					'error'				=> null
				]
			];
			if(is_string($userID) === true){
				switch(strtoupper($type)){
					case 'ACTIVE':
						$type = 1;
					break;
					default:
						$type = 1;
					break;
				}
				$find = $this->_db->get($this->_table->fields, $this->_table->name, '`user_id` = ? AND `ww_status` = ?', array($userID, $type));
				if($find->errorStatus() === false AND $find->dataCount() == 1){
					return $find->getFirstResult();
				} else {
					$tmpResponse->message->error = $dem;
					return $tmpResponse;
				}
			} else {
				$tmpResponse->message->error = $dem;
				return null;
			}
		}

		public function register($data = null, $isContributor = true){
			$dem = 'Registration failed. Please try again later.';
			if($this->_parseRegisterData($data) === true AND $this->__parseAddressData($data) === true){
				// data parsed successfully
				$isPhoneUnique = $this->_isPhoneUnique($data->userPhone);
				$isEmailUnique = $this->_isEmailUnique($data->uesrEmail);
				if($isPhoneUnique === true AND $isEmailUnique === true){
					// email is unique, start registration
					$userRole = $this->_role->findByTitle($this->_type);
					if(is_object($userRole) === false OR isset($userRole->id) === false){
						$this->setError($dem);
						return false;
					}
					$registerPerson = $this->_create((object)[
						'firstName'			=> $data->firstName,
						'surname'				=> $data->lastName,
						'cnic'					=> '',
					]);
					if($registerPerson === false){
						$this->setError($dem);
						return false;
					}
					$tmpUserID = Hash::unique();
					$createUser = $this->_db->insert('users', array(
						'user_id'					=> $tmpUserID,
						'person_id'				=> $registerPerson,
						'email'						=> $data->uesrEmail,
						'phone'						=> $data->userPhone,
						'gender'					=> $data->userGender,
						'dob'							=> $data->userDOB,
						'country'					=> strtoupper('Abc'),
						'state'						=> strtoupper($data->state),
						'city'						=> strtoupper($data->city),
						'street'					=> strtoupper($data->street),
						'token'						=> Hash::make($tmpUserID),
						'password'				=> Hash::make($data->userPassword, Hash::make($tmpUserID)),
						'role_id'					=> $userRole->id,
						'account_status'	=> 1
					));
					if($createUser->errorStatus() === false){
						$tmpResponse = (object)[
							'status'			=> false,
							'type'				=> 0,
							'message'			=> null
						];
						$tmpFileName = uniqid().'.php';
						$myfile = fopen(ROOT_PATH.'app'.DS.'views'.DS.'main'.DS.'contributor'.DS.'home_pages'.DS.$tmpFileName, "w");
						$txt = "{$data->firstName}'s web page.\n";
						fwrite($myfile, $txt);
						fclose($myfile);
						// create contributor entity
						$createContributor = $this->_db->insert($this->_table->name, array(
							'contributor_id'			=> Hash::unique(),
							'user_id'							=> $tmpUserID,
							'home_file'						=> $tmpFileName,
							'contributor_status'	=> 1
						));
						if($isContributor === false){
							return true;
						}
						// put user session
						if($this->_putUserSession($this->_userType, $tmpUserID) === true){
							// session has put successfully
							$tmpResponse->status = true;
							$tmpResponse->type = 1;
							$tmpResponse->message = 'Registered successfully.';
						} else {
							// failed to put session
							$tmpResponse->status = true;
							$tmpResponse->type = 2;
							$tmpResponse->message = 'Registered successfully. Please login to continue.';
						}
						return (object)$tmpResponse;
					} else {
						$this->setError($dem);
						return false;
					}
				} else {
					// phone || email is/are not unique, individual error is already set thorough parent class
					if($isPhoneUnique === false AND $isEmailUnique === false){
						$this->setError('Phone number and email are already in use.');
					}
					return false;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function updateProfile($data = null){
			$dem = 'Failed to update profile.';
			if(isset($data->name->first) === true AND isset($data->name->surname) === true AND $data->address->street AND $data->address->city AND $data->address->state){
				// update name
				$updateName = $this->_db->update('persons', '`first_name` = ?, `surname` = ?', '`person_id` = ?', array($data->name->first, $data->name->surname, $this->_getPrivateData('personID')));
				if($updateName->errorStatus() === true){
					$this->setError($dem);
					return false;
				}
				$update = $this->_db->update('users', '`street` = ?, `city` = ?, `state` = ?', '`user_id` = ?', array($data->address->street, $data->address->city, $data->address->state, $this->_getPrivateData('userID')));
				if($update->errorStatus() === false){
					return true;
				} else {
					$this->setError($dem);
					return false;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function changePassword($data = null){
			$dem = 'Failed to change password.';
			if($this->__parseChangePasswordData($data) === true){
				// verify old password
				if(Hash::make($data->oldPassword.$this->_getPrivateData('token')) == $this->_getPrivateData('password')){
					// verify new password
					if($data->newPassword == $data->newPasswordConfirm){
						// new password verified, change password
						$changePassword = $this->_db->update('users', '`password` = ?', '`user_id` = ?', array(Hash::make($data->newPassword.$this->_getPrivateData('token')), $this->_getPrivateData('userID')));
						if($changePassword->errorStatus() === false){
							return true;
						} else {
							$this->setError($dem);
							return false;
						}
					} else {
						// faield to verify new password
						$this->setError($dem.' New password does not match.');
						return false;
					}
				} else {
					$this->setError($dem.' You have entered incorrect password.');
					return false;
				}
			} else {
				$this->setError($dem);
				return false;
			}
		}

		// incomes
		public function addIncome($data = null){
			$dem = 'Failed to add income.';
			if(is_object($data) === false){
				$this->setError($dem);
				return false;
			}
			$data = (object)$data;
			if(isset($data->title) === false OR isset($data->amount) === false){
				$this->setError($dem);
				return false;
			}
			// validated, make income entry
			$addIncome = $this->_db->insert('incomes', array(
				'income_id'				=> Hash::unique(),
				'contributor_id'	=> $this->_getPrivateData('privateID'),
				'title'						=> $data->title,
				'amount'					=> $data->amount,
				'income_status'		=> 1
			));
			if($addIncome->errorStatus() === false){
				return true;
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function getIncomes(){
			$dem = 'Incomes not found.';
			$find = $this->_income->getContributorIncomes($this->_getPrivateData('privateID'));
			if(is_array($find) === true AND count($find) > 0){
				return $find;
			} else {
				$this->setError($this->_income->getError());
				return false;
			}
		}

		// expenses
		public function addExpense($data = null){
			$dem = 'Failed to add expense.';
			if(is_object($data) === false){
				$this->setError($dem);
				return false;
			}
			$data = (object)$data;
			if(isset($data->title) === false OR isset($data->amount) === false){
				$this->setError($dem);
				return false;
			}
			// validated, make expense entry
			$addExpense = $this->_db->insert('expenses', array(
				'expense_id'			=> Hash::unique(),
				'contributor_id'	=> $this->_getPrivateData('privateID'),
				'title'						=> $data->title,
				'amount'					=> $data->amount,
				'expense_status'	=> 1
			));
			if($addExpense->errorStatus() === false){
				return true;
			} else {
				$this->setError($dem);
				return false;
			}
		}

		public function getExpenses(){
			$dem = 'expenses not found.';
			$find = $this->_expense->getContributorExpenses($this->_getPrivateData('privateID'));
			if(is_array($find) === true AND count($find) > 0){
				return $find;
			} else {
				$this->setError($this->_expense->getError());
				return false;
			}
		}

		// summary
		public function getSummary(){
			$dem = 'Summary not found.';
			$findIncome = $this->_income->getContributorIncomes($this->_getPrivateData('privateID'));
			if(is_array($findIncome) === true AND count($findIncome) > 0){
				array_walk_recursive($findIncome, function($item, $key){
					$item->type = '1';
				});
			}
			$findExpense = $this->_expense->getContributorExpenses($this->_getPrivateData('privateID'));
			if(is_array($findExpense) === true AND count($findExpense) > 0){
				array_walk_recursive($findExpense, function($item, $key){
					$item->type = '2';
				});
			}
			$summary = array_merge($findIncome, $findExpense);
			array_multisort (array_column($summary, 'date'), SORT_DESC, $summary);
			return $summary;
		}

		// monthly summary
		public function getMonthlySummary($date = null){
			$dem = 'Summary not found.';
			$findIncome = $this->_income->getMonthlyContributorIncomes($this->_getPrivateData('privateID'), $date);
			if(is_array($findIncome) === true AND count($findIncome) > 0){
				array_walk_recursive($findIncome, function($item, $key){
					$item->type = '1';
				});
			}
			$findExpense = $this->_expense->getMonthlyContributorExpenses($this->_getPrivateData('privateID'), $date);
			if(is_array($findExpense) === true AND count($findExpense) > 0){
				array_walk_recursive($findExpense, function($item, $key){
					$item->type = '2';
				});
			}
			$summary = null;
			if(is_array($findIncome) === true AND is_array($findExpense) === true){
				$summary = array_merge($findIncome, $findExpense);
			} else {
				$summary = (is_array($findIncome) === true) ? $summary = $findIncome:$findExpense;
			}
			(isset($summary) === true AND is_array($summary) === true AND count($summary) > 0) ? array_multisort (array_column($summary, 'date'), SORT_DESC, $summary):$this->setError('There is not record in summary right now.');
			return $summary;
		}

		// monthly expense summary
		public function getMonthlyExpenseSummary($summaryDate = null){
			$dem = 'Summary not found.';
			if(is_null($summaryDate) === true OR is_string($summaryDate) === false){
				$summaryDate = date('Y-m');
			}
			$summary = array();
			for($i = 1; $i <= 31; $i++){
				array_push($summary, $this->_expense->getDailyExpense($this->_getPrivateData('privateID'), $summaryDate.'-'.$i));
			}
			return $summary;
		}

		// data parsers
		private function _parseRegisterData($data = null){
			if(is_null($data) === false AND is_object($data) === true){
				$data = (object)$data;
				if(count(get_object_vars($data)) > 0){
					if(isset($data->firstName) === true AND isset($data->lastName) === true AND isset($data->userPhone) === true AND isset($data->uesrEmail) === true AND isset($data->userPassword) === true){
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		private function __parseUpdateProfileData($data = null){
			if(is_null($data) === false AND is_object($data) === true){
				$data = (object)$data;
				if(isset($data->firstName) === true AND empty($data->firstName) === false AND isset($data->surname) === true AND empty($data->surname) === false AND isset($data->email) === true AND empty($data->email) === false AND isset($data->contact) === true AND empty($data->contact) === false){
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		private function __parseChangePasswordData($data = null){
			if(is_null($data) === false AND is_object($data) === true){
				$data = (object)$data;
				if(isset($data->oldPassword) === true AND isset($data->newPassword) === true AND isset($data->newPasswordConfirm) === true){
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

	}
?>