<?php
	class Redirect {
		public static function to($path = null, $params = null){
			if(is_null($path) === false){
				$path .= '.php';
				if(is_null($params) === false AND is_object($params) === true AND count(get_object_vars($params)) > 0){
					$path .= '?';
					$params = (object)$params;
					$count = 0;
					foreach($params as $var => $val){
						$count++;
						// die($count.','.count($params));
						$path .= $var.'='.$val;
						$path .= ($count < count(get_object_vars($params))) ? '&':'';
					}
				}
				header('location: '.SERVER_PATH.$path);
			}
		}

		public static function ifUserLoggedIn($user){
			if($user->checkLogin() !== false){
				self::to('index');
			}
		}

		public static function ifUserNotLoggedIn($user = null){
			if($user->checkLogin() === false){
				self::to('login');
			}
		}

	}
?>