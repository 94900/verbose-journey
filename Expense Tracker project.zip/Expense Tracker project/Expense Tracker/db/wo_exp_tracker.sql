-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2021 at 12:55 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wo_exp_tracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `contributors`
--

CREATE TABLE `contributors` (
  `contributor_id` varchar(32) NOT NULL,
  `user_id` varchar(32) NOT NULL,
  `home_file` varchar(20) DEFAULT NULL,
  `contributor_status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contributors`
--

INSERT INTO `contributors` (`contributor_id`, `user_id`, `home_file`, `contributor_status`) VALUES
('1ab3b22adcfff0af78a5e104a2da6d57', '7161a52a6f3cf76fb4a54b40e8e4ef0e', '61b8a3fcd8e63.php', 1),
('aaad6416e3aa51e647d414f8fc527b2a', 'f36d95d85815d9a909c81978df072d7f', '61b92de1af1c7.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expense_id` varchar(32) NOT NULL,
  `contributor_id` varchar(32) NOT NULL,
  `title` varchar(50) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expense_status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expense_id`, `contributor_id`, `title`, `amount`, `added_on`, `expense_status`) VALUES
('0e7d2b025511e5b8ff3c2befbccdaf6e', '1ab3b22adcfff0af78a5e104a2da6d57', 'Lunch', '30', '2021-12-14 15:13:34', 1),
('0ea4ab489532a964373b1b4f51fab13a', '1ab3b22adcfff0af78a5e104a2da6d57', 'Brunch', '200', '2021-12-11 16:40:55', 1),
('1f5f3ebb36a3d5d8c182b55b28c0cf6f', '1ab3b22adcfff0af78a5e104a2da6d57', 'Grocery', '300', '2021-12-14 16:40:53', 1),
('26d6442d6deb6319aa1ae22125e6135f', '1ab3b22adcfff0af78a5e104a2da6d57', 'Stationary', '100', '2021-12-14 23:53:49', 1),
('271712839dee4345cbb475024af28d07', '1ab3b22adcfff0af78a5e104a2da6d57', 'Lunch', '100', '2021-12-14 21:36:01', 1),
('2df9a3f1937ee14c0112372dd7aa76ce', '1ab3b22adcfff0af78a5e104a2da6d57', 'Tea', '70', '2021-12-13 16:40:57', 1),
('3b232b94534b31dd6b5988a87268935c', '1ab3b22adcfff0af78a5e104a2da6d57', 'Dinner', '450', '2021-12-12 16:40:53', 1),
('dad8ee40a45b4b7279ed8334786b945e', '1ab3b22adcfff0af78a5e104a2da6d57', 'Dinner', '115', '2021-12-11 16:40:53', 1),
('ed1d42cfb0fa352671c4f63bf398dd51', '1ab3b22adcfff0af78a5e104a2da6d57', 'Grocery', '150', '2021-12-13 16:40:53', 1);

-- --------------------------------------------------------

--
-- Table structure for table `incomes`
--

CREATE TABLE `incomes` (
  `income_id` varchar(32) NOT NULL,
  `contributor_id` varchar(32) NOT NULL,
  `title` varchar(50) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `income_status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `incomes`
--

INSERT INTO `incomes` (`income_id`, `contributor_id`, `title`, `amount`, `added_on`, `income_status`) VALUES
('854078f2baadb4a84bc7ab70bc2be9f2', '1ab3b22adcfff0af78a5e104a2da6d57', 'Bonus', '300', '2021-12-14 16:40:42', 1),
('89d3585c7bd6ff7a98622fd2f50ff44b', '1ab3b22adcfff0af78a5e104a2da6d57', 'Pay', '570', '2021-12-14 15:11:59', 1),
('a069eb161795afc901273a1bcf8c2aa1', '1ab3b22adcfff0af78a5e104a2da6d57', 'Bonus', '1000', '2021-12-14 23:53:15', 1),
('a38f77b7dea5365bd5e5871e2d420325', '1ab3b22adcfff0af78a5e104a2da6d57', 'Pay', '570', '2021-12-14 15:09:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE `persons` (
  `person_id` varchar(32) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `middle_name` varchar(15) DEFAULT NULL,
  `surname` varchar(15) NOT NULL,
  `cnic` varchar(15) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`person_id`, `first_name`, `middle_name`, `surname`, `cnic`, `registration_date`) VALUES
('c2b3fa998361f64572e654ab0e46740d', 'Mohsin', NULL, 'Ahmed', '', '2021-12-14 23:50:57'),
('eefe4815bcb503ceb87692600690ceed', 'Test', NULL, 'User', '', '2021-12-14 14:02:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(32) NOT NULL,
  `person_id` varchar(32) DEFAULT NULL,
  `role_id` varchar(32) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(320) NOT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `profile_pic` varchar(40) NOT NULL DEFAULT 'profile.png',
  `gender` varchar(32) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `street` varchar(256) DEFAULT NULL,
  `token` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `registered_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` timestamp NULL DEFAULT NULL,
  `deleted_on` timestamp NULL DEFAULT NULL,
  `account_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `person_id`, `role_id`, `username`, `phone`, `email`, `contact`, `profile_pic`, `gender`, `dob`, `country`, `state`, `city`, `street`, `token`, `password`, `registered_on`, `updated_on`, `deleted_on`, `account_status`) VALUES
('7161a52a6f3cf76fb4a54b40e8e4ef0e', 'eefe4815bcb503ceb87692600690ceed', '28c8edde3d61a0411511d3b1866f0636', NULL, '03001234567', 'test@gmail.com', NULL, 'profile.png', 'Male', '1995-01-01', 'ABC', 'AZAD KASHMIR', 'MIRPUR (AJK)', 'HOUSE # 887, SECTOR F-3 PART-4', '594884c6d97e656ad583badf54533fff7f3031cb6597a2c298a5b60d1e50b351', 'e302257ce6cc4f8875576bd18d9c9401d33f0ff60a16227f43ed4a5fff0d24a2', '2021-12-14 14:02:36', NULL, NULL, 1),
('f36d95d85815d9a909c81978df072d7f', 'c2b3fa998361f64572e654ab0e46740d', '28c8edde3d61a0411511d3b1866f0636', NULL, '03005418680', 'its.mohsin.ahmed@gmail.com', NULL, 'profile.png', 'Male', '1995-01-11', 'ABC', 'AZAD KASHMIR', 'MIRPUR (AJK)', 'HOUSE # 887, SECTOR F-3 PART-4', '91dbf672e0af6a95adf5001eca14f6ff815c344d189f024ece0553bdf54f97f1', 'ed1903d85789026ff73836dee304e5a8e0f672a4562cbad7cb9ee4d8d63156b2', '2021-12-14 23:50:57', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `role_id` varchar(32) NOT NULL,
  `title` varchar(30) NOT NULL,
  `table` varchar(15) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `role_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`role_id`, `title`, `table`, `created_on`, `role_status`) VALUES
('28c8edde3d61a0411511d3b1866f0636', 'WO_EXP_TRACKER_CONTRIBUTOR', 'contributors', '2021-12-14 14:02:19', 1),
('c4ca4238a0b923820dcc509a6f75849b', 'WO_EXP_TRACKER_OWNER', 'owners', '2021-12-14 14:02:19', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contributors`
--
ALTER TABLE `contributors`
  ADD PRIMARY KEY (`contributor_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expense_id`),
  ADD KEY `contributor_id` (`contributor_id`);

--
-- Indexes for table `incomes`
--
ALTER TABLE `incomes`
  ADD PRIMARY KEY (`income_id`),
  ADD KEY `contributor_id` (`contributor_id`);

--
-- Indexes for table `persons`
--
ALTER TABLE `persons`
  ADD PRIMARY KEY (`person_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contributors`
--
ALTER TABLE `contributors`
  ADD CONSTRAINT `contributors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`contributor_id`) REFERENCES `contributors` (`contributor_id`);

--
-- Constraints for table `incomes`
--
ALTER TABLE `incomes`
  ADD CONSTRAINT `incomes_ibfk_1` FOREIGN KEY (`contributor_id`) REFERENCES `contributors` (`contributor_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `user_roles` (`role_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `persons` (`person_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
