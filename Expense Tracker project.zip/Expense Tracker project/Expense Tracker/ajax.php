<?php
  require_once 'core/init.php';
  if(Input::postExists('action') === true AND Input::getPost('action') == 'monthlyExpenseSummary'){
    $monthlyExpenseSummary = $user->getMonthlyExpenseSummary(Input::getPost('summaryDate'));
    echo json_encode($monthlyExpenseSummary);
  }
?>